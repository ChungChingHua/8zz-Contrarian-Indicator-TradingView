﻿8zz 可核對戰績看板

1. 先將 8zz-dashboard-preview.zip 下載到電腦。
2. Windows：右鍵 ZIP → 解壓縮全部。
3. 在解壓縮後的資料夾，雙擊 index.html，以 Chrome 或 Edge 開啟。
請勿開啟為原始碼、另存成 .txt，或只在 GitHub 原始檔頁面閱讀。

資料、樣式與程式均已內嵌；不需安裝，不需啟動伺服器。
index.html 為257個保存事件的部分資料績效；validation-preview.html 全為模擬驗收資料。計算、Telegram操作與限制見 LIVE_PIPELINE_ACCEPTANCE.md。
© hansai-art / Group.G | Mozilla Public License 2.0
